import { Navbar } from "@/components/Navbar";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { SearchIcon, MapPin, BookmarkIcon, Bell, Settings, Filter } from "lucide-react";

// Sample job listings
const jobListings = [
  {
    id: 1,
    title: "Senior Frontend Developer",
    company: "Tech Solutions Inc.",
    location: "San Francisco, CA (Remote)",
    logo: "https://logo.clearbit.com/techinc.com",
    postedAt: "2 days ago",
    easyApply: true,
  },
  {
    id: 2,
    title: "UX/UI Designer",
    company: "Design Studio",
    location: "New York, NY",
    logo: "https://logo.clearbit.com/designstudio.com",
    postedAt: "1 day ago",
    easyApply: true,
  },
  {
    id: 3,
    title: "Full Stack Engineer",
    company: "Software Solutions",
    location: "Austin, TX (Hybrid)",
    logo: "https://logo.clearbit.com/softwaresolutions.io",
    postedAt: "3 days ago",
    easyApply: false,
  },
  {
    id: 4,
    title: "Product Manager",
    company: "Innovate Corp",
    location: "Chicago, IL",
    logo: "https://logo.clearbit.com/innovatecorp.com",
    postedAt: "4 days ago",
    easyApply: true,
  },
  {
    id: 5,
    title: "Data Scientist",
    company: "Analytics Pro",
    location: "Seattle, WA (Remote)",
    logo: "https://logo.clearbit.com/analyticspro.com",
    postedAt: "1 week ago",
    easyApply: false,
  },
  {
    id: 6,
    title: "DevOps Engineer",
    company: "Cloud Systems",
    location: "Boston, MA",
    logo: "https://logo.clearbit.com/cloudsystems.io",
    postedAt: "3 days ago",
    easyApply: true,
  },
];

export default function JobsPage() {
  return (
    <main className="min-h-screen bg-gray-100">
      <Navbar />
      <div className="container mx-auto py-6 px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* Left Sidebar */}
          <div className="md:col-span-1">
            <div className="sticky top-20 space-y-4">
              <Card>
                <CardContent className="p-4 space-y-2">
                  <Button variant="ghost" className="w-full justify-start font-medium">
                    <BookmarkIcon className="h-5 w-5 mr-2" />
                    My Jobs
                  </Button>
                  <Button variant="ghost" className="w-full justify-start font-medium">
                    <Bell className="h-5 w-5 mr-2" />
                    Job Alerts
                  </Button>
                  <Button variant="ghost" className="w-full justify-start font-medium">
                    <Settings className="h-5 w-5 mr-2" />
                    Preferences
                  </Button>
                  <Button variant="ghost" className="w-full justify-start font-medium">
                    <Filter className="h-5 w-5 mr-2" />
                    Skill Assessments
                  </Button>
                  <Button variant="ghost" className="w-full justify-start font-medium">
                    <MapPin className="h-5 w-5 mr-2" />
                    Interview Prep
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="p-4 border-b">
                  <h2 className="font-semibold">Resume Builder</h2>
                </CardHeader>
                <CardContent className="p-4">
                  <p className="text-sm text-gray-500 mb-3">Create a standout resume that will get you noticed by recruiters</p>
                  <Button className="w-full">Build Resume</Button>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Main Content */}
          <div className="md:col-span-3">
            <Card className="mb-4">
              <CardContent className="p-4">
                <div className="flex flex-col md:flex-row gap-2">
                  <div className="relative flex-grow">
                    <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
                    <Input placeholder="Search job titles or companies" className="pl-10" />
                  </div>
                  <div className="relative flex-grow">
                    <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
                    <Input placeholder="Location" className="pl-10" />
                  </div>
                  <Button className="whitespace-nowrap">Search</Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="p-4 border-b">
                <h2 className="font-semibold text-lg">Recommended Jobs</h2>
              </CardHeader>
              <CardContent className="p-0">
                <div className="divide-y">
                  {jobListings.map((job) => (
                    <div key={job.id} className="p-4 flex items-start gap-3 hover:bg-gray-50 transition">
                      <div className="w-12 h-12 flex-shrink-0">
                        <img src={job.logo} alt={job.company} className="w-full h-full object-contain rounded" />
                      </div>
                      <div className="flex-grow">
                        <h3 className="font-medium text-blue-600 hover:underline cursor-pointer">{job.title}</h3>
                        <p className="text-sm">{job.company}</p>
                        <p className="text-xs text-gray-500">{job.location}</p>
                        <p className="text-xs text-gray-500 mt-1">{job.postedAt}</p>
                        {job.easyApply && <span className="text-xs font-medium text-green-600 mt-1 block">Easy Apply</span>}
                      </div>
                      <div>
                        <Button variant="ghost" size="icon">
                          <BookmarkIcon className="h-5 w-5" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter className="p-4 border-t">
                <Button variant="outline" className="w-full">Show more jobs</Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </div>
    </main>
  );
}
