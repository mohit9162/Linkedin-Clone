import { Navbar } from "@/components/Navbar";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, MoreHorizontal, Edit, PaperclipIcon, SmileIcon, SendIcon } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";

// Sample chat data
const conversations = [
  {
    id: 1,
    name: "Sarah Johnson",
    avatar: "https://i.pravatar.cc/150?img=1",
    lastMessage: "Thanks for the information!",
    time: "2m ago",
    unread: true,
    active: true,
  },
  {
    id: 2,
    name: "Michael Chen",
    avatar: "https://i.pravatar.cc/150?img=11",
    lastMessage: "Let's schedule a call next week",
    time: "1h ago",
    unread: false,
    active: false,
  },
  {
    id: 3,
    name: "Priya Patel",
    avatar: "https://i.pravatar.cc/150?img=12",
    lastMessage: "I'm interested in the position",
    time: "3h ago",
    unread: false,
    active: false,
  },
  {
    id: 4,
    name: "Carlos Rodriguez",
    avatar: "https://i.pravatar.cc/150?img=13",
    lastMessage: "Great to connect with you",
    time: "1d ago",
    unread: false,
    active: false,
  },
];

// Sample messages for the active conversation
const messages = [
  {
    id: 1,
    sender: "Sarah Johnson",
    avatar: "https://i.pravatar.cc/150?img=1",
    message: "Hi John! I saw you're working on that new project. It looks really interesting.",
    time: "10:30 AM",
    isSelf: false,
  },
  {
    id: 2,
    sender: "John Doe",
    avatar: "/avatar-placeholder.jpg",
    message: "Yes, we just started last week. It's a challenging one but the team is great.",
    time: "10:35 AM",
    isSelf: true,
  },
  {
    id: 3,
    sender: "Sarah Johnson",
    avatar: "https://i.pravatar.cc/150?img=1",
    message: "That's awesome. I'd love to hear more about it sometime. Maybe we can grab coffee?",
    time: "10:40 AM",
    isSelf: false,
  },
  {
    id: 4,
    sender: "John Doe",
    avatar: "/avatar-placeholder.jpg",
    message: "Definitely! How about next Tuesday?",
    time: "10:42 AM",
    isSelf: true,
  },
  {
    id: 5,
    sender: "Sarah Johnson",
    avatar: "https://i.pravatar.cc/150?img=1",
    message: "Tuesday works for me. Let's say 2 PM at the cafe downtown?",
    time: "10:45 AM",
    isSelf: false,
  },
  {
    id: 6,
    sender: "John Doe",
    avatar: "/avatar-placeholder.jpg",
    message: "Sounds good! I'll add it to my calendar.",
    time: "10:48 AM",
    isSelf: true,
  },
  {
    id: 7,
    sender: "Sarah Johnson",
    avatar: "https://i.pravatar.cc/150?img=1",
    message: "Thanks for the information!",
    time: "10:50 AM",
    isSelf: false,
  },
];

export default function MessagingPage() {
  const activeConversation = conversations.find(conv => conv.active);

  return (
    <main className="min-h-screen bg-gray-100">
      <Navbar />
      <div className="container mx-auto py-6 px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Conversations List */}
          <div className="md:col-span-1">
            <Card className="h-[calc(100vh-120px)]">
              <CardHeader className="p-4 flex flex-row justify-between items-center space-y-0">
                <div className="flex gap-2 items-center">
                  <h2 className="font-semibold">Messaging</h2>
                  <MoreHorizontal className="h-4 w-4" />
                </div>
                <Button variant="ghost" size="icon">
                  <Edit className="h-5 w-5" />
                </Button>
              </CardHeader>
              <div className="p-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
                  <Input placeholder="Search messages" className="pl-10" />
                </div>
              </div>
              <CardContent className="p-0 overflow-y-auto h-[calc(100%-120px)]">
                <div className="divide-y">
                  {conversations.map((convo) => (
                    <div
                      key={convo.id}
                      className={`p-3 flex items-start gap-3 hover:bg-gray-50 transition cursor-pointer ${convo.active ? 'bg-blue-50' : ''}`}
                    >
                      <div className="relative">
                        <Avatar>
                          <AvatarImage src={convo.avatar} alt={convo.name} />
                          <AvatarFallback>{convo.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        {convo.unread && (
                          <span className="absolute bottom-0 right-0 w-3 h-3 bg-blue-600 rounded-full border-2 border-white" />
                        )}
                      </div>
                      <div className="flex-grow min-w-0">
                        <div className="flex justify-between items-baseline">
                          <h3 className="font-medium truncate">{convo.name}</h3>
                          <span className="text-xs text-gray-500 whitespace-nowrap ml-2">{convo.time}</span>
                        </div>
                        <p className="text-sm text-gray-500 truncate">{convo.lastMessage}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Chat Window */}
          <div className="md:col-span-2">
            <Card className="h-[calc(100vh-120px)] flex flex-col">
              {activeConversation ? (
                <>
                  <CardHeader className="p-4 border-b flex flex-row items-center space-y-0">
                    <div className="flex items-center gap-2">
                      <Avatar>
                        <AvatarImage src={activeConversation.avatar} alt={activeConversation.name} />
                        <AvatarFallback>{activeConversation.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="font-medium">{activeConversation.name}</h3>
                        <p className="text-xs text-gray-500">Active now</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="icon" className="ml-auto">
                      <MoreHorizontal className="h-5 w-5" />
                    </Button>
                  </CardHeader>

                  <CardContent className="p-4 overflow-y-auto flex-grow">
                    <div className="space-y-4">
                      {messages.map((message) => (
                        <div
                          key={message.id}
                          className={`flex ${message.isSelf ? 'justify-end' : 'justify-start'}`}
                        >
                          <div className={`flex gap-2 max-w-[70%] ${message.isSelf ? 'flex-row-reverse' : ''}`}>
                            <Avatar className="h-8 w-8">
                              <AvatarImage src={message.avatar} alt={message.sender} />
                              <AvatarFallback>{message.sender.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div>
                              <div
                                className={`p-3 rounded-lg ${
                                  message.isSelf
                                    ? 'bg-blue-600 text-white'
                                    : 'bg-gray-100'
                                }`}
                              >
                                {message.message}
                              </div>
                              <p className="text-xs text-gray-500 mt-1">{message.time}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>

                  <CardFooter className="p-4 border-t">
                    <div className="w-full space-y-2">
                      <Textarea
                        placeholder="Write a message..."
                        className="min-h-[60px] resize-none"
                      />
                      <div className="flex justify-between">
                        <div className="flex gap-2">
                          <Button variant="ghost" size="icon">
                            <PaperclipIcon className="h-5 w-5" />
                          </Button>
                          <Button variant="ghost" size="icon">
                            <SmileIcon className="h-5 w-5" />
                          </Button>
                        </div>
                        <Button>
                          <SendIcon className="h-4 w-4 mr-2" />
                          Send
                        </Button>
                      </div>
                    </div>
                  </CardFooter>
                </>
              ) : (
                <div className="flex items-center justify-center h-full">
                  <div className="text-center">
                    <h3 className="font-medium text-lg mb-2">No conversation selected</h3>
                    <p className="text-gray-500">Select a conversation or start a new one</p>
                  </div>
                </div>
              )}
            </Card>
          </div>
        </div>
      </div>
    </main>
  );
}
