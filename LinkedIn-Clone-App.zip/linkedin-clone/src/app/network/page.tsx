import { Navbar } from "@/components/Navbar";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { User, Users, Briefcase, Calendar, Hash } from "lucide-react";

// Sample connections data
const connectionSuggestions = [
  {
    id: 1,
    name: "Sarah Johnson",
    role: "UX Designer at Design Studio",
    avatar: "https://i.pravatar.cc/150?img=1",
    mutualConnections: 3,
  },
  {
    id: 2,
    name: "Michael Chen",
    role: "Software Engineer at Tech Solutions",
    avatar: "https://i.pravatar.cc/150?img=11",
    mutualConnections: 5,
  },
  {
    id: 3,
    name: "Priya Patel",
    role: "Product Manager at Innovate Inc.",
    avatar: "https://i.pravatar.cc/150?img=12",
    mutualConnections: 8,
  },
  {
    id: 4,
    name: "Carlos Rodriguez",
    role: "Marketing Director at Brand Co.",
    avatar: "https://i.pravatar.cc/150?img=13",
    mutualConnections: 2,
  },
  {
    id: 5,
    name: "Emma Wilson",
    role: "Data Scientist at Analytics Corp",
    avatar: "https://i.pravatar.cc/150?img=14",
    mutualConnections: 4,
  },
  {
    id: 6,
    name: "Thomas Baker",
    role: "Frontend Developer at Web Agency",
    avatar: "https://i.pravatar.cc/150?img=15",
    mutualConnections: 6,
  },
];

export default function NetworkPage() {
  return (
    <main className="min-h-screen bg-gray-100">
      <Navbar />
      <div className="container mx-auto py-6 px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* Left Sidebar */}
          <div className="md:col-span-1">
            <div className="sticky top-20 space-y-4">
              <Card>
                <CardHeader className="p-4 border-b">
                  <h2 className="font-semibold text-lg">Manage my network</h2>
                </CardHeader>
                <CardContent className="p-0">
                  <ul>
                    <li className="border-b">
                      <Button variant="ghost" className="w-full justify-start p-3">
                        <Users className="h-5 w-5 mr-2" />
                        <span>Connections</span>
                        <span className="ml-auto">412</span>
                      </Button>
                    </li>
                    <li className="border-b">
                      <Button variant="ghost" className="w-full justify-start p-3">
                        <User className="h-5 w-5 mr-2" />
                        <span>Following & Followers</span>
                        <span className="ml-auto">28</span>
                      </Button>
                    </li>
                    <li className="border-b">
                      <Button variant="ghost" className="w-full justify-start p-3">
                        <Users className="h-5 w-5 mr-2" />
                        <span>Groups</span>
                        <span className="ml-auto">6</span>
                      </Button>
                    </li>
                    <li className="border-b">
                      <Button variant="ghost" className="w-full justify-start p-3">
                        <Calendar className="h-5 w-5 mr-2" />
                        <span>Events</span>
                        <span className="ml-auto">0</span>
                      </Button>
                    </li>
                    <li className="border-b">
                      <Button variant="ghost" className="w-full justify-start p-3">
                        <Hash className="h-5 w-5 mr-2" />
                        <span>Hashtags</span>
                        <span className="ml-auto">12</span>
                      </Button>
                    </li>
                    <li>
                      <Button variant="ghost" className="w-full justify-start p-3">
                        <Briefcase className="h-5 w-5 mr-2" />
                        <span>Pages</span>
                        <span className="ml-auto">8</span>
                      </Button>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <h3 className="font-medium mb-2">Your contact import is ready</h3>
                  <p className="text-sm text-gray-500 mb-3">Connect with your contacts and never lose touch</p>
                  <Button className="w-full">Continue</Button>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Main Content */}
          <div className="md:col-span-3">
            <Card className="mb-4">
              <CardHeader className="p-4 border-b">
                <h2 className="font-semibold text-lg">Invitations</h2>
              </CardHeader>
              <CardContent className="p-0">
                <p className="p-4 text-gray-500">No pending invitations</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="p-4 border-b">
                <h2 className="font-semibold text-lg">People you may know</h2>
              </CardHeader>
              <CardContent className="p-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {connectionSuggestions.map((person) => (
                    <Card key={person.id} className="overflow-hidden">
                      <div className="h-16 bg-gray-100"></div>
                      <CardContent className="p-4 pt-2 relative">
                        <Avatar className="h-16 w-16 absolute -top-8 left-4 border-4 border-white">
                          <AvatarImage src={person.avatar} alt={person.name} />
                          <AvatarFallback>{person.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="mt-8">
                          <h3 className="font-medium">{person.name}</h3>
                          <p className="text-xs text-gray-500 mb-2">{person.role}</p>
                          <p className="text-xs text-gray-500 mb-3">{person.mutualConnections} mutual connections</p>
                          <div className="flex gap-2">
                            <Button className="flex-1">Connect</Button>
                            <Button variant="outline" className="flex-1">Message</Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </main>
  );
}
