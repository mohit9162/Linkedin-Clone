import { Navbar } from "@/components/Navbar";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { ThumbsUp, MessageSquare, Briefcase, Users, BellRing, UserPlus } from "lucide-react";

// Sample notifications data
const notifications = [
  {
    id: 1,
    type: "connection",
    user: {
      name: "Sarah Johnson",
      role: "UX Designer at Design Studio",
      avatar: "https://i.pravatar.cc/150?img=1",
    },
    content: "wants to connect with you",
    time: "2h ago",
    unread: true,
  },
  {
    id: 2,
    type: "like",
    user: {
      name: "Michael Chen",
      role: "Software Engineer at Tech Solutions",
      avatar: "https://i.pravatar.cc/150?img=11",
    },
    content: "liked your post: 'Just completed the new React project...'",
    time: "5h ago",
    unread: true,
  },
  {
    id: 3,
    type: "comment",
    user: {
      name: "Priya Patel",
      role: "Product Manager at Innovate Inc.",
      avatar: "https://i.pravatar.cc/150?img=12",
    },
    content: "commented on your post: 'Great work! I'd love to hear more about the challenges you faced.'",
    time: "1d ago",
    unread: false,
  },
  {
    id: 4,
    type: "job",
    user: {
      name: "LinkedIn Jobs",
      role: "",
      avatar: "https://logo.clearbit.com/linkedin.com",
    },
    content: "New jobs matching 'Frontend Developer' are available",
    time: "1d ago",
    unread: false,
  },
  {
    id: 5,
    type: "birthday",
    user: {
      name: "Carlos Rodriguez",
      role: "Marketing Director at Brand Co.",
      avatar: "https://i.pravatar.cc/150?img=13",
    },
    content: "is celebrating a birthday today. Say happy birthday!",
    time: "3h ago",
    unread: true,
  },
  {
    id: 6,
    type: "view",
    user: {
      name: "Emma Wilson",
      role: "Data Scientist at Analytics Corp",
      avatar: "https://i.pravatar.cc/150?img=14",
    },
    content: "viewed your profile",
    time: "2d ago",
    unread: false,
  },
];

// Function to render icon based on notification type
const getNotificationIcon = (type: string) => {
  switch (type) {
    case "connection":
      return <UserPlus className="h-6 w-6 text-blue-600" />;
    case "like":
      return <ThumbsUp className="h-6 w-6 text-blue-600" />;
    case "comment":
      return <MessageSquare className="h-6 w-6 text-blue-600" />;
    case "job":
      return <Briefcase className="h-6 w-6 text-blue-600" />;
    case "birthday":
      return <BellRing className="h-6 w-6 text-blue-600" />;
    case "view":
      return <Users className="h-6 w-6 text-blue-600" />;
    default:
      return <BellRing className="h-6 w-6 text-blue-600" />;
  }
};

export default function NotificationsPage() {
  return (
    <main className="min-h-screen bg-gray-100">
      <Navbar />
      <div className="container mx-auto py-6 px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* Left Sidebar */}
          <div className="md:col-span-1">
            <div className="sticky top-20 space-y-4">
              <Card>
                <CardHeader className="p-4 border-b">
                  <h2 className="font-semibold text-lg">Notifications</h2>
                </CardHeader>
                <CardContent className="p-0">
                  <ul>
                    <li className="border-b">
                      <Button variant="ghost" className="w-full justify-start p-3 bg-blue-50">
                        <BellRing className="h-5 w-5 mr-2 text-blue-600" />
                        <span>All</span>
                      </Button>
                    </li>
                    <li className="border-b">
                      <Button variant="ghost" className="w-full justify-start p-3">
                        <UserPlus className="h-5 w-5 mr-2" />
                        <span>My Network</span>
                      </Button>
                    </li>
                    <li className="border-b">
                      <Button variant="ghost" className="w-full justify-start p-3">
                        <Briefcase className="h-5 w-5 mr-2" />
                        <span>Jobs</span>
                      </Button>
                    </li>
                    <li className="border-b">
                      <Button variant="ghost" className="w-full justify-start p-3">
                        <MessageSquare className="h-5 w-5 mr-2" />
                        <span>Messaging</span>
                      </Button>
                    </li>
                    <li>
                      <Button variant="ghost" className="w-full justify-start p-3">
                        <ThumbsUp className="h-5 w-5 mr-2" />
                        <span>Mentions</span>
                      </Button>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Main Content */}
          <div className="md:col-span-3">
            <Card>
              <CardHeader className="p-4 border-b">
                <div className="flex justify-between items-center">
                  <h2 className="font-semibold text-lg">All Notifications</h2>
                  <Button variant="outline" size="sm">Mark all as read</Button>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <div className="divide-y">
                  {notifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-4 flex items-start gap-4 hover:bg-gray-50 transition ${notification.unread ? 'bg-blue-50' : ''}`}
                    >
                      <div>
                        {getNotificationIcon(notification.type)}
                      </div>
                      <div className="flex-grow">
                        <div className="flex items-start gap-2">
                          <Avatar>
                            <AvatarImage src={notification.user.avatar} alt={notification.user.name} />
                            <AvatarFallback>{notification.user.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="text-sm">
                              <span className="font-medium">{notification.user.name}</span> {notification.content}
                            </p>
                            {notification.user.role && (
                              <p className="text-xs text-gray-500">{notification.user.role}</p>
                            )}
                            <p className="text-xs text-gray-500 mt-1">{notification.time}</p>
                          </div>
                        </div>
                      </div>
                      <div>
                        <Button variant="ghost" size="sm">
                          ⋯
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </main>
  );
}
