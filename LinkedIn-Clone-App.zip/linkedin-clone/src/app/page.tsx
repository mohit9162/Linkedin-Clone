import { Feed } from "@/components/Feed";
import { Navbar } from "@/components/Navbar";
import { NewsSidebar } from "@/components/NewsSidebar";
import { ProfileSidebar } from "@/components/ProfileSidebar";

export default function Home() {
  return (
    <main className="min-h-screen bg-gray-100">
      <Navbar />
      <div className="container mx-auto py-6 px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="md:col-span-1">
            <div className="sticky top-20">
              <ProfileSidebar />
            </div>
          </div>
          <div className="md:col-span-2">
            <Feed />
          </div>
          <div className="md:col-span-1 hidden md:block">
            <NewsSidebar />
          </div>
        </div>
      </div>
    </main>
  );
}
