"use client";

import { useState } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Image, ThumbsUp, MessageSquare, Repeat, Send } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

type PostType = {
  id: number;
  author: {
    name: string;
    role: string;
    avatar: string;
  };
  timeAgo: string;
  content: string;
  image?: string;
  likes: number;
  comments: number;
  shares: number;
};

// Sample posts data
const initialPosts: PostType[] = [
  {
    id: 1,
    author: {
      name: "Jane Smith",
      role: "Product Designer at Design Co.",
      avatar: "https://i.pravatar.cc/150?img=5",
    },
    timeAgo: "2h",
    content: "Just finished this new design for our upcoming product launch. What do you think?",
    image: "https://images.unsplash.com/photo-1661956602116-aa6865609028?ixlib=rb-4.0.3&ixid=M3wxMjA3fDF8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1280&q=80",
    likes: 42,
    comments: 8,
    shares: 3,
  },
  {
    id: 2,
    author: {
      name: "John Doe",
      role: "Software Engineer at Tech Corp",
      avatar: "https://i.pravatar.cc/150?img=8",
    },
    timeAgo: "1d",
    content: "I'm excited to share that I've joined Tech Corp as a Senior Software Engineer! Looking forward to working with an amazing team on cutting-edge technologies.",
    likes: 128,
    comments: 24,
    shares: 5,
  },
  {
    id: 3,
    author: {
      name: "Emily Johnson",
      role: "Marketing Manager at Brand Inc.",
      avatar: "https://i.pravatar.cc/150?img=9",
    },
    timeAgo: "3d",
    content: "We just released our Q2 marketing report. Some fascinating insights on consumer behavior in the post-pandemic market.",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1280&q=80",
    likes: 76,
    comments: 12,
    shares: 8,
  },
];

export function Feed() {
  const [posts, setPosts] = useState<PostType[]>(initialPosts);
  const [newPostContent, setNewPostContent] = useState("");
  const [isPostDialogOpen, setIsPostDialogOpen] = useState(false);

  const handleCreatePost = () => {
    if (newPostContent.trim()) {
      const newPost: PostType = {
        id: posts.length + 1,
        author: {
          name: "John Doe",
          role: "Frontend Developer",
          avatar: "/avatar-placeholder.jpg",
        },
        timeAgo: "Just now",
        content: newPostContent,
        likes: 0,
        comments: 0,
        shares: 0,
      };
      setPosts([newPost, ...posts]);
      setNewPostContent("");
      setIsPostDialogOpen(false);
    }
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-2">
            <Avatar>
              <AvatarImage src="/avatar-placeholder.jpg" alt="User" />
              <AvatarFallback>JD</AvatarFallback>
            </Avatar>
            <Dialog open={isPostDialogOpen} onOpenChange={setIsPostDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" className="w-full justify-start text-gray-500 font-normal rounded-full">
                  Start a post
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle>Create a post</DialogTitle>
                  <DialogDescription>
                    Share an update or start a conversation
                  </DialogDescription>
                </DialogHeader>
                <div className="flex items-center gap-2 mb-4">
                  <Avatar>
                    <AvatarImage src="/avatar-placeholder.jpg" alt="User" />
                    <AvatarFallback>JD</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">John Doe</p>
                    <p className="text-xs text-gray-500">Post to anyone</p>
                  </div>
                </div>
                <Textarea
                  placeholder="What do you want to talk about?"
                  className="min-h-[120px]"
                  value={newPostContent}
                  onChange={e => setNewPostContent(e.target.value)}
                />
                <DialogFooter>
                  <div className="flex gap-2 w-full">
                    <Button variant="ghost" size="icon" className="rounded-full">
                      <Image className="h-5 w-5" />
                    </Button>
                    <div className="flex-grow"></div>
                    <Button onClick={handleCreatePost} disabled={!newPostContent.trim()}>
                      Post
                    </Button>
                  </div>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
          <div className="flex justify-between mt-4">
            <Button variant="ghost" className="flex items-center gap-1 text-gray-500">
              <Image className="h-5 w-5" />
              <span>Media</span>
            </Button>
            <Button variant="ghost" className="flex items-center gap-1 text-gray-500">
              <ThumbsUp className="h-5 w-5" />
              <span>Like</span>
            </Button>
            <Button variant="ghost" className="flex items-center gap-1 text-gray-500">
              <MessageSquare className="h-5 w-5" />
              <span>Comment</span>
            </Button>
            <Button variant="ghost" className="flex items-center gap-1 text-gray-500">
              <Repeat className="h-5 w-5" />
              <span>Share</span>
            </Button>
            <Button variant="ghost" className="flex items-center gap-1 text-gray-500">
              <Send className="h-5 w-5" />
              <span>Send</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {posts.map((post) => (
        <Card key={post.id}>
          <CardHeader className="p-4 pb-2">
            <div className="flex items-start gap-2">
              <Avatar>
                <AvatarImage src={post.author.avatar} alt={post.author.name} />
                <AvatarFallback>{post.author.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <div>
                <p className="font-medium">{post.author.name}</p>
                <p className="text-xs text-gray-500">{post.author.role}</p>
                <p className="text-xs text-gray-500">{post.timeAgo}</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-4 pt-2">
            <p className="text-sm mb-4">{post.content}</p>
            {post.image && (
              <img
                src={post.image}
                alt="Post content"
                className="w-full rounded-md object-cover max-h-96"
              />
            )}
          </CardContent>
          <CardFooter className="p-2 border-t flex justify-between">
            <Button variant="ghost" className="flex items-center gap-1 text-gray-500">
              <ThumbsUp className="h-4 w-4" />
              <span className="text-xs">{post.likes}</span>
            </Button>
            <Button variant="ghost" className="flex items-center gap-1 text-gray-500">
              <MessageSquare className="h-4 w-4" />
              <span className="text-xs">{post.comments}</span>
            </Button>
            <Button variant="ghost" className="flex items-center gap-1 text-gray-500">
              <Repeat className="h-4 w-4" />
              <span className="text-xs">{post.shares}</span>
            </Button>
            <Button variant="ghost" className="flex items-center gap-1 text-gray-500">
              <Send className="h-4 w-4" />
              <span className="text-xs">Send</span>
            </Button>
          </CardFooter>
        </Card>
      ))}
    </div>
  );
}
