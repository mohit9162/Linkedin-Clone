"use client";

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { Input } from "@/components/ui/input";
import { SearchIcon, Home, Users, Briefcase, MessageSquare, Bell, Menu } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

export function Navbar() {
  const pathname = usePathname();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <header className="border-b sticky top-0 z-50 bg-white">
      <div className="container mx-auto flex items-center justify-between px-4 py-2">
        <div className="flex items-center">
          <Link href="/" className="mr-4">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              data-supported-dps="24x24"
              fill="#0A66C2"
              className="h-8 w-8"
              width="24"
              height="24"
              focusable="false"
            >
              <path d="M20.5 2h-17A1.5 1.5 0 002 3.5v17A1.5 1.5 0 003.5 22h17a1.5 1.5 0 001.5-1.5v-17A1.5 1.5 0 0020.5 2zM8 19H5v-9h3zM6.5 8.25A1.75 1.75 0 118.3 6.5a1.78 1.78 0 01-1.8 1.75zM19 19h-3v-4.74c0-1.42-.6-1.93-1.38-1.93A1.74 1.74 0 0013 14.19a.66.66 0 000 .14V19h-3v-9h2.9v1.3a3.11 3.11 0 012.7-1.4c1.55 0 3.36.86 3.36 3.66z"></path>
            </svg>
          </Link>
          <div className="hidden md:flex relative">
            <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
            <Input
              type="search"
              placeholder="Search"
              className="pl-10 w-64 bg-gray-100 focus:bg-white"
            />
          </div>
        </div>

        <div className="hidden md:flex items-center space-x-1">
          <Link href="/" className={`p-2 flex flex-col items-center text-sm ${pathname === '/' ? 'text-black border-b-2 border-black' : 'text-gray-500'}`}>
            <Home className="h-6 w-6" />
            <span>Home</span>
          </Link>
          <Link href="/network" className={`p-2 flex flex-col items-center text-sm ${pathname === '/network' ? 'text-black border-b-2 border-black' : 'text-gray-500'}`}>
            <Users className="h-6 w-6" />
            <span>My Network</span>
          </Link>
          <Link href="/jobs" className={`p-2 flex flex-col items-center text-sm ${pathname === '/jobs' ? 'text-black border-b-2 border-black' : 'text-gray-500'}`}>
            <Briefcase className="h-6 w-6" />
            <span>Jobs</span>
          </Link>
          <Link href="/messaging" className={`p-2 flex flex-col items-center text-sm ${pathname === '/messaging' ? 'text-black border-b-2 border-black' : 'text-gray-500'}`}>
            <MessageSquare className="h-6 w-6" />
            <span>Messaging</span>
          </Link>
          <Link href="/notifications" className={`p-2 flex flex-col items-center text-sm ${pathname === '/notifications' ? 'text-black border-b-2 border-black' : 'text-gray-500'}`}>
            <Bell className="h-6 w-6" />
            <span>Notifications</span>
          </Link>
          <div className="border-l h-10 mx-2"></div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="p-1 flex flex-col items-center rounded-full">
                <Avatar>
                  <AvatarImage src="/avatar-placeholder.jpg" alt="User" />
                  <AvatarFallback>CN</AvatarFallback>
                </Avatar>
                <span className="text-xs">Me ▼</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>My Account</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem>Profile</DropdownMenuItem>
              <DropdownMenuItem>Settings</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem>Sign Out</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Mobile menu button */}
        <div className="md:hidden">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right">
              <div className="flex flex-col space-y-4 pt-4">
                <Link href="/" className="p-2 flex items-center text-sm">
                  <Home className="h-6 w-6 mr-2" />
                  <span>Home</span>
                </Link>
                <Link href="/network" className="p-2 flex items-center text-sm">
                  <Users className="h-6 w-6 mr-2" />
                  <span>My Network</span>
                </Link>
                <Link href="/jobs" className="p-2 flex items-center text-sm">
                  <Briefcase className="h-6 w-6 mr-2" />
                  <span>Jobs</span>
                </Link>
                <Link href="/messaging" className="p-2 flex items-center text-sm">
                  <MessageSquare className="h-6 w-6 mr-2" />
                  <span>Messaging</span>
                </Link>
                <Link href="/notifications" className="p-2 flex items-center text-sm">
                  <Bell className="h-6 w-6 mr-2" />
                  <span>Notifications</span>
                </Link>
                <div className="border-t my-2"></div>
                <div className="flex items-center p-2">
                  <Avatar className="mr-2">
                    <AvatarImage src="/avatar-placeholder.jpg" alt="User" />
                    <AvatarFallback>CN</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-medium">John Doe</p>
                    <p className="text-xs text-gray-500">View Profile</p>
                  </div>
                </div>
                <Button variant="outline">Sign Out</Button>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
