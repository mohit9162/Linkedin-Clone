"use client";

import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Info } from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";

type NewsItem = {
  id: number;
  title: string;
  time: string;
  readers: string;
};

const newsItems: NewsItem[] = [
  {
    id: 1,
    title: "Big Tech firms announce hiring spree",
    time: "2h ago",
    readers: "3,587 readers"
  },
  {
    id: 2,
    title: "Remote work trends in 2023",
    time: "4h ago",
    readers: "1,242 readers"
  },
  {
    id: 3,
    title: "The rise of AI in workplace automation",
    time: "8h ago",
    readers: "5,320 readers"
  },
  {
    id: 4,
    title: "New privacy regulations for social networks",
    time: "1d ago",
    readers: "982 readers"
  },
  {
    id: 5,
    title: "Tech industry layoffs slow down in Q2",
    time: "2d ago",
    readers: "2,184 readers"
  }
];

export function NewsSidebar() {
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="p-3 pb-1">
          <div className="flex justify-between items-center">
            <h3 className="font-bold">LinkedIn News</h3>
            <Info className="h-4 w-4" />
          </div>
        </CardHeader>
        <CardContent className="p-3 pt-1">
          <ul className="space-y-3">
            {newsItems.map((item) => (
              <li key={item.id} className="text-sm">
                <Link href="#" className="font-medium hover:text-blue-600 block">
                  • {item.title}
                </Link>
                <p className="text-xs text-gray-500 pl-2">
                  {item.time} • {item.readers}
                </p>
              </li>
            ))}
          </ul>
        </CardContent>
        <CardFooter className="p-3 pt-0">
          <Button variant="ghost" className="w-full justify-start text-gray-600 font-medium text-sm">
            Show more
          </Button>
        </CardFooter>
      </Card>

      <Card className="sticky top-20">
        <CardContent className="p-3">
          <div className="flex justify-between items-center mb-2">
            <h3 className="text-sm text-gray-500">Ad</h3>
            <Button variant="ghost" className="p-0 h-auto text-xs">•••</Button>
          </div>
          <p className="text-xs text-center mb-2">You appear to be a good fit for this position</p>
          <div className="flex items-center justify-center">
            <div className="mr-2">
              <img src="https://logo.clearbit.com/microsoft.com" alt="Microsoft Logo" className="w-10 h-10 rounded" />
            </div>
            <div>
              <h4 className="text-sm font-medium">Frontend Developer</h4>
              <p className="text-xs">Microsoft • Remote</p>
            </div>
          </div>
          <Button className="w-full mt-2 text-sm">Apply Now</Button>
        </CardContent>
      </Card>

      <div className="text-xs text-gray-500 space-x-3 px-2">
        <Link href="#" className="hover:text-blue-600 hover:underline">About</Link>
        <Link href="#" className="hover:text-blue-600 hover:underline">Accessibility</Link>
        <Link href="#" className="hover:text-blue-600 hover:underline">Help Center</Link>
        <Link href="#" className="hover:text-blue-600 hover:underline">Privacy & Terms</Link>
        <Link href="#" className="hover:text-blue-600 hover:underline">Ad Choices</Link>
        <Link href="#" className="hover:text-blue-600 hover:underline">Advertising</Link>
        <p className="mt-2">LinkedIn Corporation © 2023</p>
      </div>
    </div>
  );
}
