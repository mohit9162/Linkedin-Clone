"use client";

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Bookmark, ChevronDown, Users } from "lucide-react";
import Link from "next/link";

export function ProfileSidebar() {
  return (
    <div className="space-y-4">
      <Card className="overflow-hidden">
        <div className="bg-blue-100 h-14 relative">
          <Avatar className="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-1/3 h-16 w-16 border-2 border-white">
            <AvatarImage src="/avatar-placeholder.jpg" alt="User" />
            <AvatarFallback>JD</AvatarFallback>
          </Avatar>
        </div>
        <CardHeader className="pt-10 text-center pb-2">
          <h3 className="font-semibold text-lg">John Doe</h3>
          <p className="text-sm text-gray-500">Frontend Developer at Tech Company</p>
        </CardHeader>
        <CardContent className="px-4 py-0">
          <div className="border-t border-b py-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Who's viewed your profile</span>
              <span className="text-blue-600 font-semibold">38</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Impressions of your post</span>
              <span className="text-blue-600 font-semibold">92</span>
            </div>
          </div>
        </CardContent>
        <CardFooter className="px-4 py-2">
          <div className="text-sm">
            <p className="text-gray-500">Access exclusive tools & insights</p>
            <Link href="#" className="text-sm font-medium flex items-center gap-1 text-black">
              <div className="bg-yellow-400 w-3 h-3 rounded-sm inline-block mr-1"></div>
              Try Premium for free
            </Link>
          </div>
        </CardFooter>
        <div className="px-4 pb-2 border-t pt-2">
          <Link href="#" className="text-sm font-medium flex items-center gap-1 text-gray-600">
            <Bookmark className="h-4 w-4" />
            My items
          </Link>
        </div>
      </Card>

      <Card>
        <CardContent className="p-0">
          <div className="p-3 border-b">
            <h4 className="text-sm font-medium">Recent</h4>
            <ul className="mt-2 space-y-2">
              <li>
                <Link href="#" className="text-xs flex items-center text-gray-600 hover:text-black hover:bg-gray-100 p-1 rounded">
                  <Users className="h-3 w-3 mr-2" />
                  React Developers Group
                </Link>
              </li>
              <li>
                <Link href="#" className="text-xs flex items-center text-gray-600 hover:text-black hover:bg-gray-100 p-1 rounded">
                  <Users className="h-3 w-3 mr-2" />
                  Frontend Masters
                </Link>
              </li>
              <li>
                <Link href="#" className="text-xs flex items-center text-gray-600 hover:text-black hover:bg-gray-100 p-1 rounded">
                  <Users className="h-3 w-3 mr-2" />
                  JavaScript Enthusiasts
                </Link>
              </li>
            </ul>
          </div>
          <div className="p-3">
            <h4 className="text-sm font-medium text-blue-600">Groups</h4>
            <ul className="mt-2 space-y-2">
              <li>
                <Link href="#" className="text-xs flex items-center text-gray-600 hover:text-black hover:bg-gray-100 p-1 rounded">
                  <Users className="h-3 w-3 mr-2" />
                  Web Development
                </Link>
              </li>
              <li>
                <Link href="#" className="text-xs flex items-center text-gray-600 hover:text-black hover:bg-gray-100 p-1 rounded">
                  <Users className="h-3 w-3 mr-2" />
                  UI/UX Designers
                </Link>
              </li>
            </ul>

            <div className="mt-2">
              <Link href="#" className="text-sm flex items-center text-gray-600 hover:text-black font-medium">
                See all
                <ChevronDown className="h-4 w-4" />
              </Link>
            </div>
          </div>

          <div className="p-3 border-t">
            <Link href="#" className="text-sm flex items-center text-gray-600 hover:text-black font-medium">
              Events
              <span className="ml-auto">+</span>
            </Link>
          </div>

          <div className="p-3 border-t">
            <Link href="#" className="text-sm flex items-center text-gray-600 hover:text-black font-medium">
              Followed Hashtags
            </Link>
          </div>
        </CardContent>
        <CardFooter className="p-3 border-t">
          <Link href="#" className="text-sm text-center w-full text-gray-600 hover:text-black font-medium">
            Discover more
          </Link>
        </CardFooter>
      </Card>
    </div>
  );
}
